<?php
//display errores muestra las alertas en caso de variables vacías
error_reporting(E_ALL);
ini_set('display_errors', 1);
//Array principal
$arrayFinal = array();
//Sub array, puede ser 1, 2, 3 o N cantidad de sub array que necesitemos 
$subArray = array();

//Modo debug nos permite inyectar variables desde el navegador con el método GET y verificar el array JSON que obtendremos de respuesta
if(isset($_GET["debug"])){
	$correo = $_GET["correo"];
	$password = $_GET["password"];

}else{
	//las siguientes 3 lineas convierten el array json a un array php
	$handle = fopen('php://input','r');
	$jsonInput = fgets($handle);
	$post = json_decode($jsonInput,true);
	$correo = $post["correo"];
	$password = $post["password"];
	$key = $post["key"];
	
	if($key != "123456abcde" || $correo == "" || $password == ""){
		$subArray['error'] = 3;
		$subArray['error_mensaje'] = "No tienes los permisos necesarios";
		array_push($arrayFinal,$subArray);//empujamos el subarray ($subArray) al array final ($arrayFinal)
		echo json_encode($arrayFinal);
		exit;
	}
}
//Conexión a la base de datos con los parámetros (host / usuario / contraseña / base de datos) consecutivamente 
$connection = mysqli_connect( "localhost", "root", "", "veterinaria" );
//Consulta a la base de datos para extraer la información de un usuario por su correo electrónico
$qu = mysqli_query($connection,"SELECT id,nombre,correo FROM usuarios_login WHERE correo = '$correo' AND password = '$password'") or die(mysqli_error($connection));
//recorremos los resultados obtenidos de la consulta en la linea 17 y los vamos empujando al sub array --> $subArray
if(mysqli_num_rows($qu) >= 1){//si se encontraron resultados
	while($r = mysqli_fetch_array($qu)){
		$subArray['error'] = 1;
		$subArray['error_mensaje'] = "todo correcto";
		$subArray['id'] = (string)$r['id'];
		$subArray['nombre'] = $r['nombre'];
		$subArray['correo'] = $r['correo'];
		//$subArray['pais'] = $r["pais"];
		//empujamos el subarray ($subArray) al array final ($arrayFinal)
		array_push($arrayFinal,$subArray);
	}
}else{//no se encontro ningun resultado, mandamos mensaje de error para ser evaluado por la app
	$subArray['error'] = 2;
	$subArray['error_mensaje'] = "No se encontraron resultados";
	array_push($arrayFinal,$subArray);//empujamos el subarray ($subArray) al array final ($arrayFinal)
}

if(isset($_GET["debug"])){
	echo "<pre>";
	print_r($arrayFinal);
	echo "</pre>";
}else{
	echo json_encode($arrayFinal);
}
?>