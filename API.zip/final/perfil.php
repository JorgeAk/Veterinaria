curso_swiftcurso_swiftcurso_swiftpaispaispais<?php
//display errores muestra las alertas en caso de variables vacías
error_reporting(E_ALL);
ini_set('display_errors', 1);


//Array principal
$arrayFinal = array();
//Sub array, puede ser 1, 2, 3 o N cantidad de sub array que necesitemos 
$subArray = array();

//Modo debug nos permite inyectar variables desde el navegador con el método GET y verificar el array JSON que obtendremos de respuesta
if(isset($_GET["debug"])){
	$nombre = $_GET["nombre"];
	$correo = $_GET["correo"];
	$imagen = $_GET["imagen"];

}else{
	//las siguientes 3 lineas convierten el array json a un array php
	$handle = fopen('php://input','r');
	$jsonInput = fgets($handle);
	$post = json_decode($jsonInput,true);
	$nombre = $post["nombre"];
	$correo = $post["correo"];
	$imagen = $post["imagen"];
	$key = $post["key"];
	//$pais = $post["pais"];
	
	//validamos que las variables no esten vacias
	if($key != "123456abcde" || $nombre == "" || $correo == "" ){
		$subArray['error'] = 3;
		$subArray['error_mensaje'] = "No tienes los permisos necesarios";
		array_push($arrayFinal,$subArray);//empujamos el subarray ($subArray) al array final ($arrayFinal)
		echo json_encode($arrayFinal);
		exit;
	}
}

//Conexión a la base de datos con los parámetros (host / usuario / contraseña / base de datos) consecutivamente 
$connection = mysqli_connect( "localhost", "root", "", "veterinaria" );

//Consulta a la base de datos verificar si ay existe un usuario registrado con ese correo
$qu = mysqli_query($connection,"SELECT id FROM usuarios_login WHERE correo = '$correo'") or die(mysqli_error($connection));


//recorremos los resultados obtenidos de la consulta en la linea 17 y los vamos empujando al sub array --> $subArra
if(mysqli_num_rows($qu) >= 1){//si se encontraron resultados

	mysqli_query($connection,"INSERT INTO usuarios_login (nombre,correo,password) VALUES ('$nombre','$correo','$password')") or die(mysqli_error($connection));	
	$id = mysqli_insert_id($connection);
	
	$subArray['error'] = 1;
	$subArray['error_mensaje'] = "todo correcto";
	$subArray['id'] = (string)$id;
	$subArray['nombre'] = $nombre;
	$subArray['correo'] = $correo;
	//$subArray['pais'] = $pais;
	array_push($arrayFinal,$subArray);//empujamos el subarray ($subArray) al array final ($arrayFinal)
	
}else{//SI no existe el correo en nuestra base de datos creamos un nuevo registro del usuario
	
	while($r = mysqli_fetch_array($qu)){
		$subArray['error'] = 2;
		$subArray['error_mensaje'] = "Eror";
		$subArray['id'] = (string)$r['id'];
		$subArray['nombre'] = $r['nombre'];
		$subArray['correo'] = $r['correo'];
		//empujamos el subarray ($subArray) al array final ($arrayFinal)
		array_push($arrayFinal,$subArray);
	}
}


if(isset($_GET["debug"])){
	echo "<pre>";
	print_r($arrayFinal);
	echo "</pre>";
}else{
	echo json_encode($arrayFinal);
}
?>