curso_swiftcurso_swiftcurso_swiftpaispaispais<?php
//display errores muestra las alertas en caso de variables vacías
error_reporting(E_ALL);
ini_set('display_errors', 1);


//Array principal
$arrayFinal = array();
//Sub array, puede ser 1, 2, 3 o N cantidad de sub array que necesitemos 
$subArray = array();

//Modo debug nos permite inyectar variables desde el navegador con el método GET y verificar el array JSON que obtendremos de respuesta
if(isset($_GET["debug"])){
	$fecha = $_GET["fecha"];
	$servicio = $_GET["servicio"];
	$paciente = $_GET["paciente"];
	

}else{
	//las siguientes 3 lineas convierten el array json a un array php
	$handle = fopen('php://input','r');
	$jsonInput = fgets($handle);
	$post = json_decode($jsonInput,true);
	$fecha = $post["fecha"];
	$servicio = $post["servicio"];
	$paciente = $post["paciente"];
	$key = $post["key"];
	//$pais = $post["pais"];
	
	//validamos que las variables no esten vacias
	if($key != "123456abcde" || $fecha == "" || $servicio == "" || $paciente == ""){
		$subArray['error'] = 3;
		$subArray['error_mensaje'] = "No tienes los permisos necesarios";
		array_push($arrayFinal,$subArray);//empujamos el subarray ($subArray) al array final ($arrayFinal)
		echo json_encode($arrayFinal);
		exit;
	}
}

//Conexión a la base de datos con los parámetros (host / usuario / contraseña / base de datos) consecutivamente 
$connection = mysqli_connect( "localhost", "root", "", "veterinaria" );

//Consulta a la base de datos verificar si ay existe un usuario registrado con ese correo
$qu = mysqli_query($connection,"SELECT id FROM servicios WHERE fecha = '$fecha'") or die(mysqli_error($connection));


//recorremos los resultados obtenidos de la consulta en la linea 17 y los vamos empujando al sub array --> $subArra
if(mysqli_num_rows($qu) >= 1){//si se encontraron resultados
	while($r = mysqli_fetch_array($qu)){
		$subArray['error'] = 2;
		$subArray['error_mensaje'] = "Ya no hay fichas disponibles elige otra fecha u hora";
		$subArray['id'] = (string)$r['id'];
		$subArray['fecha'] = $r['fecha'];
		$subArray['servicio'] = $r['servicio'];
		$subArray['paciente'] = $r['paciente'];
		//empujamos el subarray ($subArray) al array final ($arrayFinal)
		array_push($arrayFinal,$subArray);
	}
}else{//SI no existe el correo en nuestra base de datos creamos un nuevo registro del usuario
	
	mysqli_query($connection,"INSERT INTO servicios (fecha,servicio,paciente) VALUES ('$fecha','$servicio','$paciente')") or die(mysqli_error($connection));	
	$id = mysqli_insert_id($connection);
	
	$subArray['error'] = 1;
	$subArray['error_mensaje'] = "todo correcto";
	$subArray['id'] = (string)$id;
	$subArray['fecha'] = $fecha;
	$subArray['servicio'] = $servicio;
	$subArray['paciente'] = $paciente;
	//$subArray['pais'] = $pais;
	array_push($arrayFinal,$subArray);//empujamos el subarray ($subArray) al array final ($arrayFinal)
}


if(isset($_GET["debug"])){
	echo "<pre>";
	print_r($arrayFinal);
	echo "</pre>";
}else{
	echo json_encode($arrayFinal);
}
?>