<?php
//display errores muestra las alertas en caso de variables vacías
error_reporting(E_ALL);
ini_set('display_errors', 1);


//Array principal
$arrayFinal = array();
//Sub array, puede ser 1, 2, 3 o N cantidad de sub array que necesitemos 
$subArray = array();

//Modo debug nos permite inyectar variables desde el navegador con el método GET y verificar el array JSON que obtendremos de respuesta
if(isset($_GET["debug"])){
	$nombre = $_GET["nombre"];
	$precio = $_GET["precio"];
	$imagen = $_GET["imagen"];

}else{
	//las siguientes 3 lineas convierten el array json a un array php
	$handle = fopen('php://input','r');
	$jsonInput = fgets($handle);
	$post = json_decode($jsonInput,true);
	$nombre = $post["nombre"];
	$precio = $_post["precio"];
	$imagen = $post["imagen"];
	$key = $post["key"];
	
	
}

//Conexión a la base de datos con los parámetros (host / usuario / contraseña / base de datos) consecutivamente 
$connection = mysqli_connect( "localhost", "root", "", "veterinaria" );

//Consulta a la base de datos para extraer la información 
$qu = mysqli_query($connection,"SELECT id,nombre,imagen,precio FROM productos") or die(mysqli_error($connection));

//recorremos los resultados obtenidos de la consulta en la linea 17 y los vamos empujando al sub array --> $subArray
if(mysqli_num_rows($qu) >= 1){//si se encontraron resultados
	while($r = mysqli_fetch_array($qu)){
		$subArray['error'] = 1;
		$subArray['error_mensaje'] = "todo correcto";
		$subArray['id'] = (string)$r['id'];
		$subArray['nombre'] = $r['nombre'];
		$subArray['imagen'] = $r['imagen'];
		$subArray['precio'] = $r['precio'];
		//$subArray['pais'] = $r["pais"];
		//empujamos el subarray ($subArray) al array final ($arrayFinal)
		array_push($arrayFinal,$subArray);
	}
}else{//no se encontro ningun resultado, mandamos mensaje de error para ser evaluado por la app
	$subArray['error'] = 2;
	$subArray['error_mensaje'] = "No se encontraron resultados";
	array_push($arrayFinal,$subArray);//empujamos el subarray ($subArray) al array final ($arrayFinal)
}

if(isset($_GET["debug"])){
	echo "<pre>";
	print_r($arrayFinal);
	echo "</pre>";
}else{
	echo json_encode($arrayFinal);
}
?>