//
//  PerfilController.swift
//  PROYECTO
//
//  Created by Jorge on 28/05/20.
//  Copyright © 2020 MAC. All rights reserved.
//

import UIKit

class PerfilController: UIViewController {
    var nombre: String = ""
       var id: String = ""
       var correo: String = ""
    
    @IBOutlet weak var lblUsuario: UILabel!
    
    @IBOutlet weak var lblCorreo: UILabel!
    
    @IBOutlet weak var textUsuario: UITextField!
    @IBOutlet weak var textCorreo: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblUsuario.text = self.nombre
        self.lblCorreo.text = self.correo
        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func btnActualizar(_ sender: Any) {
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
