//
//  ProductosController.swift
//  PROYECTO
//
//  Created by Jorge on 07/05/20.
//  Copyright © 2020 MAC. All rights reserved.
//

import UIKit

class ProductosController: UIViewController {
   
    @IBOutlet weak var lblNombre: UILabel!
    
    @IBOutlet weak var lblPrecio: UILabel!
    
    @IBOutlet weak var lblNombre2: UILabel!
    
    @IBOutlet weak var lblPrecio2: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func btnComprar1(_ sender: Any) {
        let inicioVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "carrito") as! CarritoController
        inicioVc.Nombre = "PRO PLAN"
         inicioVc.Precio = "600.00"
         
        self.navigationController?.pushViewController(inicioVc, animated: true)
    }
    
    @IBAction func btnComprar2(_ sender: Any) {
        let inicioVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "carrito") as! CarritoController
        inicioVc.Nombre = "ADVANCE"
         inicioVc.Precio = "300.00"
         
        self.navigationController?.pushViewController(inicioVc, animated: true)
    }
    
}
