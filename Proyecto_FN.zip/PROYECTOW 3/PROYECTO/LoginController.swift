//
//  LoginController.swift
//  PROYECTO
//
//  Created by Jorge on 06/05/20.
//  Copyright © 2020 MAC. All rights reserved.
//

import UIKit

class LoginController: UIViewController {

    @IBOutlet weak var emailText: UITextField!
    @IBOutlet weak var errorLabel: UILabel!
    @IBOutlet weak var paswordText: UITextField!
    @IBOutlet weak var btnLogin: UIButton!
    let dataJsonUrlClass=JsonClass()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func bnLogin(_ sender: Any) {
        let correo = emailText.text
        let password = paswordText.text
        
        if correo == "" || password == ""{
            return
        }
        
        //Creamos un array (diccionario) de datos para ser enviados en la petición hacia el servidor remoto, aqui pueden existir N cantidad de valores
        let datos_a_enviar = ["correo": correo!, "password": password!] as NSMutableDictionary
        //ejecutamos la función arrayFromJson con los parámetros correspondientes (url archivo .php / datos a enviar)
        
        dataJsonUrlClass.arrayFromJson(url:"final/login.php",datos_enviados:datos_a_enviar){ (array_respuesta) in
            DispatchQueue.main.async {//proceso principal
                
                /*
                 object(at: 0) as! NSDictionary -> indica que el elemento 0 de nuestro array lo vamos a convertir en un diccionario de datos.
                 */
                let diccionario_datos = array_respuesta?.object(at: 0) as! NSDictionary
                //ahora ya podemos acceder a cada valor por medio de su key "forKey"
                if let errormensaje = diccionario_datos.object(forKey: "error_mensaje") as! String?{
                                   self.errorLabel.text = errormensaje
                                   if let error = diccionario_datos.object(forKey: "error") as! Int?{
                                    if(error == 1){//registro exitoso, lo redirigimos a la view de inicio
                                        
                                        //instanciamos el viewcontroller "inicio" para enviar parametros y empujar la vista con "pushViewController"
                                        let inicioVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Menu") as! MenuController
                                        inicioVc.nombre = diccionario_datos.object(forKey: "nombre") as! String
                                        inicioVc.correo = diccionario_datos.object(forKey: "correo") as! String
                                        inicioVc.id = diccionario_datos.object(forKey: "id") as! String
                                        self.navigationController?.pushViewController(inicioVc, animated: true)
                                                              

                                                             
                                                          }
                                    }
                                                 }
                
                        }
                    }
                
                
        
    }
    
}
