//
//  ViewController.swift
//  PROYECTO
//
//  Created by MAC on 3/19/20.
//  Copyright © 2020 MAC. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
   
    
    @IBOutlet var BtnLogin: UIButton!
    @IBOutlet var BtnRegistrar: UIButton!
    @IBOutlet var ImgInicio: UIImageView!
    

    
    
    
    @IBOutlet var leanding: NSLayoutConstraint!
    @IBOutlet var trailing: NSLayoutConstraint!
    var MenuOut = false
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
       // ImgInicio.layer.cornerRadius = ImgInicio.frame.size.width / 2
        //ImgInicio.clipsToBounds = true
        BtnLogin.layer.cornerRadius = 10
        BtnRegistrar.layer.cornerRadius = 10
    
        
        
       
    }
    
    // MARK: - Navigation
       override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
           // Check segue identifier
           if segue.identifier == "push" {
               // Get SecondVC
               let destinationVC = segue.destination as! LoginController
               
               // Pass text to SecondVC
              
           }else{
            if segue.identifier == "pushR" {
                
                let destinationVC = segue.destination as! RegisterController
            }
        }
       }
    
    
    @IBAction func MenuTapped(_ sender: Any) {
        if MenuOut == false {
            leanding.constant = 150
            trailing.constant = -150
            MenuOut = true
        }else {
            leanding.constant = 0
            trailing.constant = 0
            MenuOut = false
        }
    }
    
}




