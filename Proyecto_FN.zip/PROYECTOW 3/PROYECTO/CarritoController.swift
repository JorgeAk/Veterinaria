//
//  CarritoController.swift
//  PROYECTO
//
//  Created by Jorge on 28/05/20.
//  Copyright © 2020 MAC. All rights reserved.
//

import UIKit

class CarritoController: UIViewController{
    var Nombre: String = ""
    var Precio: String = ""
    // ligar tabla
    
    @IBOutlet weak var lblNombre: UILabel!
    @IBOutlet weak var lblPrecio: UILabel!
    
    @IBOutlet weak var lblTotal: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.lblNombre.text = "ADVANCE"
        self.lblPrecio.text = "300.00"
        self.lblTotal.text = "300.00"
        


        

        // Do any additional setup after loading the view.
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
