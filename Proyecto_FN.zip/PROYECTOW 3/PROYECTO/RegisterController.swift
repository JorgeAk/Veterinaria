//
//  RegisterController.swift
//  PROYECTO
//
//  Created by Jorge on 07/05/20.
//  Copyright © 2020 MAC. All rights reserved.
//

import UIKit

class RegisterController: UIViewController {

    @IBOutlet weak var NombreText: UITextField!
    @IBOutlet weak var correoText: UITextField!
    @IBOutlet weak var PaswordText: UITextField!
    @IBOutlet weak var ConPaswordText: UITextField!
    @IBOutlet weak var errorLabel: UILabel!
    @IBOutlet weak var BtnEnviar: UIButton!
    
    let dataJsonUrlClass = JsonClass()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btEnviar(_ sender: Any) {
        //extraemos el valor del campo de texto (ID usuario)
        let nombre = NombreText.text
        let correo = correoText.text
        let password = PaswordText.text
        
        //si idText.text no tienen ningun valor terminamos la ejecución
        if nombre == "" || correo == "" || password == ""{
            return
        }
        
        //Creamos un array (diccionario) de datos para ser enviados en la petición hacia el servidor remoto, aqui pueden existir N cantidad de valores
        let datos_a_enviar = ["nombre":nombre!, "correo": correo!, "password": password!] as NSMutableDictionary
               //ejecutamos la función arrayFromJson con los parámetros correspondientes (url archivo .php / datos a enviar)
               
               dataJsonUrlClass.arrayFromJson(url:"final/register.php",datos_enviados:datos_a_enviar){ (array_respuesta) in
                   DispatchQueue.main.async {//proceso principal
                       
                       /*
                        object(at: 0) as! NSDictionary -> indica que el elemento 0 de nuestro array lo vamos a convertir en un diccionario de datos.
                        */
                       //let diccionario_datos = array_respuesta?.object(at: 0) as! NSDictionary
                       //ahora ya podemos acceder a cada valor por medio de su key "forKey"
                    let inicioVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "init") as! ViewController
                      
                    self.navigationController?.pushViewController(inicioVc, animated: true)
                    
                     /*  if let errormensaje = diccionario_datos.object(forKey: "error_mensaje") as! String?{
                                          self.errorLabel.text = errormensaje
                                          if let error = diccionario_datos.object(forKey: "error") as! Int?{
                                           if(error == 1){//registro exitoso, lo redirigimos a la view de inicio
                                        
                                               //instanciamos el viewcontroller "inicio" para enviar parametros y empujar la vista con "pushViewController"
                                               let inicioVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Menu") as! ViewController
                                                 
                                               self.navigationController?.pushViewController(inicioVc, animated: true)
                                                                     

                                                                    
                                                                 }
                                           }
                                                        }*/
                       
                               }
                           
                     
       
    }
    
   
}
}

