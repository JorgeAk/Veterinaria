//
//  ProductosTableViewCell.swift
//  PROYECTO
//
//  Created by Jorge on 31/05/20.
//  Copyright © 2020 MAC. All rights reserved.
//

import UIKit

class ProductosTableViewCell: UITableViewCell {

    @IBOutlet weak var lblnombreCell: UILabel!
    @IBOutlet weak var imgCell: UIImageView!
    @IBOutlet weak var lblprecioCell: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBAction func btnComprar(_ sender: UIButton) {
        let inicioVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "carrito") as! CarritoController
        inicioVc.Nombre = "PRO PLAN"
        inicioVc.Precio = "600.00"
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    

}
