//
//  UbicacionController.swift
//  PROYECTO
//
//  Created by Jorge on 07/05/20.
//  Copyright © 2020 MAC. All rights reserved.
//

import UIKit
import MapKit

struct Stadium {
  var name: String
  var lattitude: CLLocationDegrees
  var longtitude: CLLocationDegrees
}

class UbicacionController: UIViewController {
let locationManager = CLLocationManager()
    @IBOutlet weak var mapView: MKMapView!
    let stadiums = [Stadium(name: "Morelia", lattitude: 19.7006, longtitude: -101.1861942),
    Stadium(name: "Tecnologico de Morelia", lattitude: 19.7229386, longtitude: -101.1858201)]
    override func viewDidLoad() {
        super.viewDidLoad()
        checkLocationServices()
        fetchStadiumsOnMap(stadiums)

        // Do any additional setup after loading the view.
    }
    func checkLocationServices() {
      if CLLocationManager.locationServicesEnabled() {
        checkLocationAuthorization()
      } else {
        
      }
    }
    
    func checkLocationAuthorization() {
      switch CLLocationManager.authorizationStatus() {
      case .authorizedWhenInUse:
        mapView.showsUserLocation = true
        
      case .denied:
        break
      case .notDetermined:
        locationManager.requestWhenInUseAuthorization()
        mapView.showsUserLocation = true
      case .restricted:
        break
      case .authorizedAlways:
        break
      }
    }
    
    func fetchStadiumsOnMap(_ stadiums: [Stadium]) {
      for stadium in stadiums {
        let annotations = MKPointAnnotation()
        annotations.title = stadium.name
        annotations.coordinate = CLLocationCoordinate2D(latitude: stadium.lattitude, longitude: stadium.longtitude)
        mapView.addAnnotation(annotations)
      }
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
