//
//  ServiciosTableViewController.swift
//  PROYECTO
//
//  Created by Jorge on 29/05/20.
//  Copyright © 2020 MAC. All rights reserved.
//

import UIKit
struct Servicios {
    var isoCode: String
    var name: String
}
class ServiciosTableViewController: UITableViewController {
    
    let servicios = [
         Servicios(isoCode: "v1", name: "Manejo de heridas"),
         Servicios(isoCode: "v3", name: "Urgencias"),
         Servicios(isoCode: "v4", name: "Oftalmologia"),
         Servicios(isoCode: "v5", name: "Medicina interna"),
         Servicios(isoCode: "v12", name: "Medicina preventiva"),
     ]
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }


    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return servicios.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CountryCell", for: indexPath)

        let servicio = servicios[indexPath.row]
        cell.textLabel?.text = servicio.name
        //cell.detailTextLabel?.text = servicio.isoCode
        cell.imageView?.image = UIImage(named: servicio.isoCode)

        return cell
    }


}
