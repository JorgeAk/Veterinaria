//
//  Productos2ViewController.swift
//  PROYECTO
//
//  Created by Jorge on 31/05/20.
//  Copyright © 2020 MAC. All rights reserved.
//

import UIKit

class Productos2ViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {
    let productos = [
        Productos(isoCode: "producto1", name: "PRO PLAN",precio:"600.00"),
        Productos(isoCode: "producto7", name: "ADVANCE",precio:"300"),
        Productos(isoCode: "producto3", name: "Pro3",precio:"200"),
        Productos(isoCode: "producto5", name: "Cesar",precio:"100"),
        Productos(isoCode: "producto6", name: "Comedero",precio:"400"),
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnComprar(_ sender: UIButton) {
        let inicioVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "carrito") as! CarritoController
               inicioVc.Nombre = "PRO PLAN"
               inicioVc.Precio = "600.00"
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        productos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "productoCell", for: indexPath) as! ProductosTableViewCell
       
        let producto = productos[indexPath.row]
        cell.lblnombreCell.text = producto.name
        //cell.detailTextLabel?.text = producto.isoCode
        cell.lblprecioCell.text = producto.precio
        cell.imgCell.image = UIImage(named: producto.isoCode)
        // add border and color
        cell.backgroundColor = UIColor.white
        cell.layer.borderColor = UIColor.black.cgColor
        cell.layer.borderWidth = 1
        cell.layer.cornerRadius = 10
        cell.clipsToBounds = true
        
        return cell
    }
    
    
    
    override func didReceiveMemoryWarning() {
       super.didReceiveMemoryWarning()
       // Dispose of any resources that can be recreated.
    }
    
    struct Productos {
        var isoCode: String
        var name: String
        var precio:String
    }
    

    

}
