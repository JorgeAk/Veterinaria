//
//  ProductosTableViewController.swift
//  PROYECTO
//
//  Created by Jorge on 29/05/20.
//  Copyright © 2020 MAC. All rights reserved.
//

import UIKit

struct Productos {
    var isoCode: String
    var name: String
    var precio:String
}

class ProductosTableViewController: UITableViewController {
    let productos = [
        Productos(isoCode: "producto1", name: "PRO PLAN",precio:"600.00"),
        Productos(isoCode: "producto2", name: "ADVANCE",precio:"100"),
        Productos(isoCode: "producto3", name: "Pro3",precio:"200"),
        Productos(isoCode: "producto5", name: "Pro5",precio:"100"),
        Productos(isoCode: "producto6", name: "Pro6",precio:"400"),
    ]
   

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }


    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productos.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "productoCell", for: indexPath)

        let producto = productos[indexPath.row]
        cell.textLabel?.text = producto.name
        //cell.detailTextLabel?.text = producto.isoCode
        cell.textLabel?.text = producto.precio
        cell.imageView?.image = UIImage(named: producto.isoCode)

        return cell
    }

    

}
