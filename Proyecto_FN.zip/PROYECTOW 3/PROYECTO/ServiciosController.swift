//
//  ServiciosController.swift
//  PROYECTO
//
//  Created by Jorge on 07/05/20.
//  Copyright © 2020 MAC. All rights reserved.
//

import UIKit



class ServiciosController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
     let serviciosList = [Servicios(isoCode: "v3", name: "MANEJO DE HERIDAS"),
     Servicios(isoCode: "v1", name: "URGENCIAS"),
     Servicios(isoCode: "v4", name: "OFTALMOLOGIA"),
     Servicios(isoCode: "v6", name: "MEDICINA INTERNA"),
     Servicios(isoCode: "v8", name: "MEDICINA PREVENTIVA"),
     Servicios(isoCode: "v10", name: "LABORATORIO"),]
    
     
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return serviciosList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ServiciosCell", for: indexPath) as! ServiciosTableViewCell
        
        let servicio = serviciosList[indexPath.row]
        cell.labelCell.text = servicio.name
        cell.imageCell.image = UIImage(named: servicio.isoCode)
              return cell
    }
    
    override func didReceiveMemoryWarning() {
          super.didReceiveMemoryWarning()
          // Dispose of any resources that can be recreated.
       }
    
    struct Servicios {
        var isoCode: String
        var name: String
        
    }

    

}
